import Arithmetics
import unittest


class unittest_arithmetics(unittest.TestCase):

    def run_time_test(self):
        arithmetics = Arithmetics.Arithmetics()


        self.assertAlmostEqual(arithmetics.addition(5, 5), 10)

        self.assertEqual(arithmetics.addition(4, 4), 8)

        self.assertNotEqual(arithmetics.addition(5, 3), 7)

        self.assertAlmostEqual(arithmetics.substraction(5, 2), 3)

        self.assertEqual(arithmetics.substraction(8, 2), 6)

        self.assertNotEqual(arithmetics.substraction(2, 2), 1)

        self.assertEqual(arithmetics.multiplication(6, 1), 6, )#Pass

        self.assertEqual(arithmetics.multiplication(5, 1), 5, )#Pass

        self.assertNotEqual(arithmetics.multiplication(6, 3), 18, )  #Pass

        self.assertLessEqual(arithmetics.multiplication(5, 2), 10)

        self.assertGreaterEqual(arithmetics.multiplication(6, 2), 6)

        self.assertEqual(arithmetics.division(10, 2), 5,)#Pass

        self.assertEqual(arithmetics.modulas(10, 2), 0, )#Pass
