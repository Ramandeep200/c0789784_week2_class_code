import unittest_arithmetics
import time
import logging

def test_name(name):
    assert name == 'Ramandeep kaur'


if __name__ == '__main__':
    start = time.time()

    unittest_arithmetics.unittest_arithmetics().run_time_test()

    end = time.time()

    logging.info('{}'.format(start))
    logging.info('{}'.format(end))
